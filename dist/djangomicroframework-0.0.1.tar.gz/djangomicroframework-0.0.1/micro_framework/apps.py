from django.apps import AppConfig


class MicroFrameworkConfig(AppConfig):
    name = 'micro_framwork'
    verbose_name = "Django Micro framework"
