from django.apps import AppConfig


class AuthJWTTokenConfig(AppConfig):
    name = 'micro_framwork.jwt_auth'
    verbose_name = "JWT Auth Token"
